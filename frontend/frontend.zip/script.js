const api = "http://a5c0732b8322b4f4c997f2ad297389ee-1404353653.us-east-1.elb.amazonaws.com:5000/cars";

function loadCars(){

fetch(api)

.then(res => res.json())

.then(data => {

let output=""

data.forEach(car=>{

output += `<p>${car[1]} - ${car[2]}</p>`

})

document.getElementById("output").innerHTML=output

})

}

function addCar(){

let name=document.getElementById("name").value

let brand=document.getElementById("brand").value

fetch(api,{

method:"POST",

headers:{

"Content-Type":"application/json"

},

body:JSON.stringify({

name:name,

brand:brand

})

})

.then(res=>res.json())

.then(data=>{

alert("Car Added Successfully")

loadCars()

})

}

loadCars()